#include <string.h>
#include "dvm_pri.h"

ErrorDefinition dvm_error_message_format[] = {
    {"dummy"},
    {"不正なマルチバイト文字です。"},
    {"関数$(name)が見付かりません。"},
    {"関数$(name)が重複定義されています。"},
    {"dummy"}
};
